package com.cardboardvr.mixin;

import com.cardboardvr.StereoState;
import com.mojang.blaze3d.opengl.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GlStateManager.class)
public abstract class GlStateManagerMixin {

    /**
     * Every render pass that targets the window framebuffer sets the viewport to the full target.
     * While an eye is being drawn we narrow it to that eye's half of the screen.
     */
    @Inject(method = "_viewport(IIII)V", at = @At("HEAD"), cancellable = true)
    private static void cardboardvr$viewport(int x, int y, int width, int height, CallbackInfo ci) {
        if (StereoState.inViewportHook) {
            return;
        }
        if (x == 0 && y == 0 && StereoState.isMainSize(width, height)) {
            StereoState.inViewportHook = true;
            try {
                GlStateManager._viewport(StereoState.regionX(), 0, StereoState.regionWidth(), height);
            } finally {
                StereoState.inViewportHook = false;
            }
            ci.cancel();
        }
    }
}
