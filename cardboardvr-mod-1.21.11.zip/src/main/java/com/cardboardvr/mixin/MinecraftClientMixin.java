package com.cardboardvr.mixin;

import com.cardboardvr.StereoState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    /** During an eye pass the game draws into the half-width eye target instead of the window target. */
    @Inject(method = "getFramebuffer", at = @At("HEAD"), cancellable = true)
    private void cardboardvr$framebuffer(CallbackInfoReturnable<Framebuffer> cir) {
        Framebuffer override = StereoState.override;
        if (override != null) {
            cir.setReturnValue(override);
        }
    }
}
