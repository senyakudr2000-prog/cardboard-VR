package com.cardboardvr.mixin;

import com.cardboardvr.StereoState;
import com.mojang.blaze3d.opengl.GlCommandEncoder;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.textures.GpuTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GlCommandEncoder.class)
public abstract class GlCommandEncoderMixin {

    /**
     * The world renderer clears the whole window framebuffer at the start of every world pass,
     * which would wipe the other eye. While stereo is active, limit that clear to the current half.
     */
    @Inject(method = "clearColorAndDepthTextures(Lcom/mojang/blaze3d/textures/GpuTexture;ILcom/mojang/blaze3d/textures/GpuTexture;D)V",
            at = @At("HEAD"), cancellable = true)
    private void cardboardvr$clear(GpuTexture color, int colorValue, GpuTexture depth, double depthValue,
                                   CallbackInfo ci) {
        if (color == null || depth == null) {
            return;
        }
        int w = color.getWidth(0);
        int h = color.getHeight(0);
        if (StereoState.isMainSize(w, h)) {
            ((CommandEncoder) (Object) this).clearColorAndDepthTextures(
                    color, colorValue, depth, depthValue,
                    StereoState.regionX(), 0, StereoState.regionWidth(), h);
            ci.cancel();
        }
    }
}
