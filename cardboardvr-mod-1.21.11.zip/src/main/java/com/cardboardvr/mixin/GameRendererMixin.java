package com.cardboardvr.mixin;

import com.cardboardvr.StereoRenderer;
import com.cardboardvr.StereoState;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    /** Replace the normal frame with two eye passes when stereo is on. */
    @Inject(method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V",
            at = @At("HEAD"), cancellable = true)
    private void cardboardvr$render(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        if (!StereoState.enabled || StereoState.rendering) {
            return;
        }
        StereoRenderer.renderStereo((GameRenderer) (Object) this, tickCounter, tick);
        ci.cancel();
    }

    // --- Per-eye projection -------------------------------------------------------------
    // 1.21.11 has two projection builders: the public getBasicProjectionMatrix(F) and the
    // private getProjectionMatrix(F). The private one may call the public one, so we make sure
    // the tweak is applied exactly once per resulting matrix.

    @Inject(method = "getProjectionMatrix(F)Lorg/joml/Matrix4f;", at = @At("HEAD"))
    private void cardboardvr$projHead(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        StereoState.projDepth++;
        StereoState.projApplied = false;
    }

    @Inject(method = "getProjectionMatrix(F)Lorg/joml/Matrix4f;", at = @At("RETURN"), cancellable = true)
    private void cardboardvr$projReturn(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        StereoState.projDepth = Math.max(0, StereoState.projDepth - 1);
        if (StereoState.rendering && !StereoState.projApplied) {
            cir.setReturnValue(StereoState.applyProjection(cir.getReturnValue()));
        }
        StereoState.projApplied = false;
    }

    @Inject(method = "getBasicProjectionMatrix(F)Lorg/joml/Matrix4f;", at = @At("RETURN"), cancellable = true)
    private void cardboardvr$basicProjection(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (!StereoState.rendering) {
            return;
        }
        cir.setReturnValue(StereoState.applyProjection(cir.getReturnValue()));
        if (StereoState.projDepth > 0) {
            StereoState.projApplied = true;
        }
    }
}
