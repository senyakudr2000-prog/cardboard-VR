package com.cardboardvr;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cardboardvr.properties");

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (InputStream in = Files.newInputStream(FILE)) {
            Properties p = new Properties();
            p.load(in);
            StereoState.ipd = clamp(Float.parseFloat(p.getProperty("ipd", "0.064")));
            StereoState.enabled = Boolean.parseBoolean(p.getProperty("enabled", "false"));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("ipd", Float.toString(StereoState.ipd));
        p.setProperty("enabled", Boolean.toString(StereoState.enabled));
        try (OutputStream out = Files.newOutputStream(FILE)) {
            p.store(out, "Cardboard VR config");
        } catch (IOException ignored) {
        }
    }

    public static float clamp(float v) {
        return Math.max(0.0f, Math.min(0.5f, v));
    }
}
