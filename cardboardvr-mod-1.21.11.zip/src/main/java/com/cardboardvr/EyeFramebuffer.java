package com.cardboardvr;

import net.minecraft.client.gl.Framebuffer;

/** A plain colour+depth render target for one eye. */
public final class EyeFramebuffer extends Framebuffer {
    public EyeFramebuffer(String name, int width, int height) {
        super(name, true);
        this.initFbo(width, height);
    }
}
