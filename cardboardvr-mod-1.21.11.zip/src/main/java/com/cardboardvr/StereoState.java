package com.cardboardvr;

import net.minecraft.client.gl.Framebuffer;
import org.joml.Matrix4f;

/** Global state of the stereo renderer. */
public final class StereoState {
    /** Split screen enabled by the player. */
    public static boolean enabled = false;
    /** True while we are inside our own per-eye render passes. */
    public static boolean rendering = false;
    /** 0 = left eye, 1 = right eye (valid only while rendering). */
    public static int eye = 0;
    /** Distance between the eyes, in blocks (~metres). */
    public static float ipd = 0.064f;

    /** While non-null, MinecraftClient.getFramebuffer() returns this (half-width eye target). */
    public static Framebuffer override = null;

    /** Bookkeeping so the projection tweak is applied exactly once per matrix. */
    public static int projDepth = 0;
    public static boolean projApplied = false;

    private StereoState() {}

    /**
     * Per-eye projection: half the aspect ratio (each eye gets half the screen)
     * and a sideways shift of the view by half the eye separation.
     * Returns a new matrix; the input is not modified.
     */
    public static Matrix4f applyProjection(Matrix4f projection) {
        float shift = (eye == 0 ? 1.0f : -1.0f) * ipd * 0.5f;
        return new Matrix4f(projection).scale(2.0f, 1.0f, 1.0f).translate(shift, 0.0f, 0.0f);
    }
}
