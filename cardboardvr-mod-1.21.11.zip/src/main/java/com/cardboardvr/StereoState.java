package com.cardboardvr;

import org.joml.Matrix4f;

/** Global state of the stereo renderer. */
public final class StereoState {
    /** Split screen enabled by the player. */
    public static boolean enabled = false;
    /** Swap which half shows which eye. */
    public static boolean swapEyes = false;
    /** Distance between the eyes, in blocks (~metres). */
    public static float ipd = 0.064f;

    /** True while we are inside our own per-eye render passes. */
    public static boolean rendering = false;
    /** 0 = left eye, 1 = right eye (valid only while rendering). */
    public static int eye = 0;
    /** Size of the real window framebuffer (valid only while rendering). */
    public static int mainW = 0;
    public static int mainH = 0;

    /** Re-entrancy guard for the viewport hook. */
    public static boolean inViewportHook = false;

    /** Bookkeeping so the projection tweak is applied exactly once per matrix. */
    public static int projDepth = 0;
    public static boolean projApplied = false;

    private StereoState() {}

    /** Left edge (in pixels) of the half of the screen the current eye is drawn into. */
    public static int regionX() {
        int slot = swapEyes ? 1 - eye : eye;
        return slot * (mainW / 2);
    }

    public static int regionWidth() {
        return Math.max(1, mainW / 2);
    }

    /** True if a render target of this size is the window framebuffer. */
    public static boolean isMainSize(int w, int h) {
        return rendering && w == mainW && h == mainH && mainW > 1;
    }

    /**
     * Per-eye projection: half the aspect ratio (each eye gets half the screen)
     * and a sideways shift of the view by half the eye separation.
     * Returns a new matrix; the input is not modified.
     */
    public static Matrix4f applyProjection(Matrix4f projection) {
        float shift = (eye == 0 ? 1.0f : -1.0f) * ipd * 0.5f;
        return new Matrix4f(projection).scale(2.0f, 1.0f, 1.0f).translate(shift, 0.0f, 0.0f);
    }
}
