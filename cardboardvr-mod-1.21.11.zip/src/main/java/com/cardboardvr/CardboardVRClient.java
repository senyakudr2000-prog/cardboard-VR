package com.cardboardvr;

import com.mojang.brigadier.arguments.FloatArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class CardboardVRClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("cardboardvr", "main"));

    private static KeyBinding toggleKey;
    private static KeyBinding ipdUpKey;
    private static KeyBinding ipdDownKey;

    @Override
    public void onInitializeClient() {
        Config.load();
        // Always start switched off so a broken state can never lock you out of the game.
        StereoState.enabled = false;

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, CATEGORY));
        ipdUpKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.ipd_up", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_ADD, CATEGORY));
        ipdDownKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.ipd_down", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_SUBTRACT, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                setEnabled(client, !StereoState.enabled);
            }
            while (ipdUpKey.wasPressed()) {
                changeIpd(client, +0.005f);
            }
            while (ipdDownKey.wasPressed()) {
                changeIpd(client, -0.005f);
            }
        });

        // Chat commands: handy on a phone where F8 / numpad are hard to reach.
        //   /cardboardvr            toggle
        //   /cardboardvr on | off
        //   /cardboardvr ipd <v>    eye separation, e.g. 0.064
        //   /cardboardvr swap       swap left/right eye images
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("cardboardvr")
                        .executes(ctx -> {
                            setEnabled(MinecraftClient.getInstance(), !StereoState.enabled);
                            return 1;
                        })
                        .then(ClientCommandManager.literal("on").executes(ctx -> {
                            setEnabled(MinecraftClient.getInstance(), true);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("off").executes(ctx -> {
                            setEnabled(MinecraftClient.getInstance(), false);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("swap").executes(ctx -> {
                            StereoState.swapEyes = !StereoState.swapEyes;
                            Config.save();
                            message(MinecraftClient.getInstance(),
                                    "Cardboard VR: eyes swapped = " + StereoState.swapEyes);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("ipd")
                                .then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0.0f, 0.5f))
                                        .executes(ctx -> {
                                            StereoState.ipd = Config.clamp(FloatArgumentType.getFloat(ctx, "value"));
                                            Config.save();
                                            message(MinecraftClient.getInstance(),
                                                    String.format("Cardboard VR: eye separation %.3f", StereoState.ipd));
                                            return 1;
                                        })))));
    }

    private static void setEnabled(MinecraftClient client, boolean value) {
        StereoState.enabled = value;
        Config.save();
        message(client, "Cardboard VR: " + (value ? "ON" : "OFF"));
    }

    private static void changeIpd(MinecraftClient client, float delta) {
        StereoState.ipd = Config.clamp(StereoState.ipd + delta);
        Config.save();
        message(client, String.format("Cardboard VR: eye separation %.3f", StereoState.ipd));
    }

    private static void message(MinecraftClient client, String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), true);
        }
    }
}
