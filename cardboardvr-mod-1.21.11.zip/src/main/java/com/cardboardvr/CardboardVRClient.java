package com.cardboardvr;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class CardboardVRClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("cardboardvr", "main"));

    private static KeyBinding toggleKey;
    private static KeyBinding ipdUpKey;
    private static KeyBinding ipdDownKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, CATEGORY));
        ipdUpKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.ipd_up", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_ADD, CATEGORY));
        ipdDownKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cardboardvr.ipd_down", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_SUBTRACT, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                StereoState.enabled = !StereoState.enabled;
                Config.save();
                message(client, "Cardboard VR: " + (StereoState.enabled ? "ON" : "OFF"));
            }
            while (ipdUpKey.wasPressed()) {
                changeIpd(client, +0.005f);
            }
            while (ipdDownKey.wasPressed()) {
                changeIpd(client, -0.005f);
            }
        });
    }

    private static void changeIpd(MinecraftClient client, float delta) {
        StereoState.ipd = Config.clamp(StereoState.ipd + delta);
        Config.save();
        message(client, String.format("Cardboard VR: eye separation %.3f", StereoState.ipd));
    }

    private static void message(MinecraftClient client, String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), true);
        }
    }
}
