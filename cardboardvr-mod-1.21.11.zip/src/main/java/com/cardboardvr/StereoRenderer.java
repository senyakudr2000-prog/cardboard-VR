package com.cardboardvr;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Draws the whole frame twice straight into the window framebuffer: the left eye into the left
 * half and the right eye into the right half. No extra framebuffers and no texture copies are
 * used (those are the parts that misbehave on Android GL translation layers). Instead the GL
 * viewport is narrowed to one half for every pass (see GlStateManagerMixin) and full-target
 * clears are limited to that half (see GlCommandEncoderMixin).
 */
public final class StereoRenderer {
    private static final Logger LOGGER = LoggerFactory.getLogger("cardboardvr");

    private StereoRenderer() {}

    public static void renderStereo(GameRenderer renderer, RenderTickCounter tickCounter, boolean tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer main = mc.getFramebuffer();
        StereoState.mainW = main.textureWidth;
        StereoState.mainH = main.textureHeight;
        StereoState.projDepth = 0;
        StereoState.projApplied = false;
        StereoState.inViewportHook = false;
        StereoState.rendering = true;
        try {
            for (int eye = 0; eye < 2; eye++) {
                StereoState.eye = eye;
                renderer.render(tickCounter, tick);
            }
        } catch (RuntimeException e) {
            // Never crash the game because of the VR view: switch it off and report.
            LOGGER.error("Cardboard VR rendering failed, disabling stereo mode", e);
            StereoState.enabled = false;
            Config.save();
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("Cardboard VR: error, disabled (see log)"), true);
            }
        } finally {
            StereoState.rendering = false;
            StereoState.inViewportHook = false;
        }
    }
}
