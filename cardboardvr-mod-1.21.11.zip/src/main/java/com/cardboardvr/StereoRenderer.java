package com.cardboardvr;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Renders the whole frame twice (left eye, right eye), each into its own
 * half-width framebuffer, then copies both side by side into the real main
 * framebuffer ("half side-by-side", the layout Cardboard viewers expect).
 * Because every eye target is exactly half as wide as the screen, the GUI gets
 * squeezed into each half automatically and the world uses a half-aspect projection.
 */
public final class StereoRenderer {
    private static final Logger LOGGER = LoggerFactory.getLogger("cardboardvr");

    private static EyeFramebuffer leftEye;
    private static EyeFramebuffer rightEye;

    private StereoRenderer() {}

    public static void renderStereo(GameRenderer renderer, RenderTickCounter tickCounter, boolean tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer main = mc.getFramebuffer(); // the real one: no override active here
        int w = main.textureWidth;
        int h = main.textureHeight;
        int half = Math.max(1, w / 2);

        try {
            leftEye = ensure(leftEye, "cardboardvr_left", half, h);
            rightEye = ensure(rightEye, "cardboardvr_right", half, h);

            StereoState.projDepth = 0;
            StereoState.projApplied = false;
            StereoState.rendering = true;
            try {
                renderEye(renderer, tickCounter, tick, 0, leftEye);
                renderEye(renderer, tickCounter, tick, 1, rightEye);
            } finally {
                StereoState.rendering = false;
                StereoState.override = null;
            }

            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.copyTextureToTexture(leftEye.getColorAttachment(), main.getColorAttachment(),
                    0, 0, 0, 0, 0, half, h);
            encoder.copyTextureToTexture(rightEye.getColorAttachment(), main.getColorAttachment(),
                    0, half, 0, 0, 0, half, h);
        } catch (RuntimeException e) {
            // Never crash the game because of the VR view: switch it off and report.
            LOGGER.error("Cardboard VR rendering failed, disabling stereo mode", e);
            StereoState.enabled = false;
            StereoState.rendering = false;
            StereoState.override = null;
            Config.save();
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("Cardboard VR: error, disabled (see log)"), true);
            }
        }
    }

    private static void renderEye(GameRenderer renderer, RenderTickCounter tickCounter, boolean tick,
                                  int eye, Framebuffer target) {
        StereoState.eye = eye;
        StereoState.override = target;
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.clearColorAndDepthTextures(target.getColorAttachment(), 0, target.getDepthAttachment(), 1.0);
        renderer.render(tickCounter, tick);
        StereoState.override = null;
    }

    private static EyeFramebuffer ensure(EyeFramebuffer fb, String name, int w, int h) {
        if (fb == null) {
            return new EyeFramebuffer(name, w, h);
        }
        if (fb.textureWidth != w || fb.textureHeight != h) {
            fb.resize(w, h);
        }
        return fb;
    }
}
