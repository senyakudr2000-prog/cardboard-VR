# Cardboard VR Split Screen (Fabric 1.21.11)

Client-side mod: draws the frame twice (left eye / right eye) into the two halves of the screen.

- F8 or chat command `/cardboardvr` - toggle (the mod always starts switched OFF)
- `/cardboardvr on` / `/cardboardvr off`
- `/cardboardvr ipd 0.064` - eye separation (also Numpad + / -)
- `/cardboardvr swap` - swap the two halves

Use Fast graphics (not Fabulous).
Build: `gradle build` (Java 21, Gradle 9.2.1) -> build/libs/cardboardvr-1.0.0.jar
