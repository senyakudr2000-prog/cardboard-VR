# Cardboard VR Split Screen (Fabric 1.21.11)

Client-side mod: splits the screen into left/right eye images (half side-by-side) for Cardboard viewers.

- F8 — toggle stereo
- Numpad + / Numpad - — eye separation (saved to config/cardboardvr.properties)

Build: `gradle build` (Java 21, Gradle 9.2.1) -> build/libs/cardboardvr-1.0.0.jar
